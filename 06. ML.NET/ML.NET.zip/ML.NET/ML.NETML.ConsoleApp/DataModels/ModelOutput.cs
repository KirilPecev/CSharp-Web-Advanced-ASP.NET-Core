//*****************************************************************************************
//*                                                                                       *
//* This is an auto-generated file by Microsoft ML.NET CLI (Command-Line Interface) tool. *
//*                                                                                       *
//*****************************************************************************************

namespace ML.NETML.ConsoleApp.DataModels
{
    public class ModelOutput
    {
        public float Score { get; set; }
    }
}
